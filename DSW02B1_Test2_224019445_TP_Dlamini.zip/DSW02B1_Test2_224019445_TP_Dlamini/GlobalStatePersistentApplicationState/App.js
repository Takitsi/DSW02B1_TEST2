import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { AppProvider } from './context/AppContext';
import HomeScreen from './screens/HomeScreen';
import ServicesScreen from './screens/ServicesScreen';
import SavedServicesScreen from './screens/SavedServicesScreen';
import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';


export default function App() {
  return (
    <AppProvider>
      <NavigationContainer>
        {/* your navigation stack or tabs */}
      </NavigationContainer>
    </AppProvider>
  );
}
