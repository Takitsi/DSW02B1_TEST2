import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { useApp } from '../context/AppContext';

export default function ServicesScreen() {
  const { savedServices, addSavedService, removeSavedService } = useApp();

  const services = [
    { id: 1, title: 'Library Support' },
    { id: 2, title: 'ICT Helpdesk' },
    { id: 3, title: 'Career Services' },
  ];

  return (
    <View>
      {services.map((service) => {
        const isSaved = savedServices.some((s) => s.id === service.id);
        return (
          <Pressable
            key={service.id}
            onPress={() =>
              isSaved ? removeSavedService(service.id) : addSavedService(service)
            }
          >
            <Text>
              {service.title} {isSaved ? '✅ Saved' : '➕ Save'}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
