import React from 'react';
import { View, Text } from 'react-native';
import { useApp } from '../context/AppContext';

export default function SavedServicesScreen() {
  const { savedServices } = useApp();

  if (savedServices.length === 0) {
    return <Text>No saved services yet.</Text>;
  }

  return (
    <View>
      {savedServices.map((s) => (
        <Text key={s.id}>{s.title}</Text>
      ))}
    </View>
  );
}
