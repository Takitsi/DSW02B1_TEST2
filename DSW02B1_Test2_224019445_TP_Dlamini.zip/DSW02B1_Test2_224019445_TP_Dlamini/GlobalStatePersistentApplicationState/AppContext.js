import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [savedServices, setSavedServices] = useState([]);
  const [theme, setTheme] = useState('light'); 
  useEffect(() => {
    const loadData = async () => {
      try {
        const storedServices = await AsyncStorage.getItem('@UJ_savedServices');
        const storedTheme = await AsyncStorage.getItem('@UJ_theme');
        if (storedServices) setSavedServices(JSON.parse(storedServices));
        if (storedTheme) setTheme(storedTheme);
      } catch (err) {
        console.log('Error loading data', err);
      }
    };
    loadData();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem('@UJ_savedServices', JSON.stringify(savedServices));
    AsyncStorage.setItem('@UJ_theme', theme);
  }, [savedServices, theme]);

  const addSavedService = (service) => {
    setSavedServices((prev) => {
      if (prev.find((s) => s.id === service.id)) return prev; 
      return [...prev, service];
    });
  };

  const removeSavedService = (id) => {
    setSavedServices((prev) => prev.filter((s) => s.id !== id));
  };

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  return (
    <AppContext.Provider
      value={{ savedServices, addSavedService, removeSavedService, theme, toggleTheme }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
