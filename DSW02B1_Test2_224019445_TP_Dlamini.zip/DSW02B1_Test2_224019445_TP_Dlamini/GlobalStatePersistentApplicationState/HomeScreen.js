import React from 'react';
import { View, Text } from 'react-native';
import { useApp } from '../context/AppContext';

export default function HomeScreen() {
  const { savedServices } = useApp();

  return (
    <View>
      <Text>Saved Services: {savedServices.length}</Text>
    </View>
  );
  const { theme, toggleTheme } = useApp();

<Pressable onPress={toggleTheme}>
  <Text>Switch to {theme === 'light' ? 'Dark' : 'Light'} Mode</Text>
</Pressable>

}
