import React, { useEffect, useState } from "react";

import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from "react-native";

import { doc, getDoc } from "firebase/firestore";

import { signOut } from "firebase/auth";

import { auth, db } from "./firebase";

export default function ProfileScreen() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = async () => {
    try {
      const user = auth.currentUser;

      if (!user) {
        return;
      }

      const profileRef = doc(db, "users", user.uid);

      const profileSnapshot = await getDoc(profileRef);

      if (profileSnapshot.exists()) {
        setProfile(profileSnapshot.data());
      } else {
        Alert.alert(
          "Profile",
          "Your profile could not be found."
        );
      }
    } catch (error) {
      Alert.alert(
        "Error",
        "Unable to load your profile."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProfile();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);

      setProfile(null);
    } catch (error) {
      Alert.alert(
        "Error",
        "Unable to sign out."
      );
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />

        <Text style={styles.loadingText}>
          Loading profile...
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        My Profile
      </Text>

      {profile && (
        <View style={styles.card}>
          <Text style={styles.heading}>
            Student Name
          </Text>

          <Text style={styles.value}>
            {profile.studentName}
          </Text>

          <Text style={styles.heading}>
            Email
          </Text>

          <Text style={styles.value}>
            {profile.email}
          </Text>
        </View>
      )}

      <TouchableOpacity
        style={styles.logoutButton}
        onPress={handleLogout}
      >
        <Text style={styles.logoutText}>
          Sign Out
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 25,
    paddingTop: 70,
    backgroundColor: "#ffffff",
  },

  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  loadingText: {
    marginTop: 15,
    fontSize: 16,
  },

  title: {
    fontSize: 30,
    fontWeight: "bold",
    marginBottom: 30,
  },

  card: {
    padding: 20,
    borderWidth: 1,
    borderColor: "#dddddd",
    borderRadius: 10,
    marginBottom: 30,
  },

  heading: {
    fontSize: 16,
    fontWeight: "bold",
    marginTop: 10,
  },

  value: {
    fontSize: 18,
    marginTop: 5,
    marginBottom: 10,
  },

  logoutButton: {
    backgroundColor: "#cc0000",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
  },

  logoutText: {
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "bold",
  },
});