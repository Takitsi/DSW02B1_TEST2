import React, { useEffect, useState } from "react";

import {
  View,
  Text,
  ActivityIndicator,
  StyleSheet,
} from "react-native";

import { onAuthStateChanged } from "firebase/auth";

import { auth } from "./firebase";

import AuthScreen from "./AuthScreen";
import ProfileScreen from "./ProfileScreen";

export default function App() {
  const [user, setUser] = useState(null);

  const [checkingAuth, setCheckingAuth] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(
      auth,
      (currentUser) => {
        setUser(currentUser);

        setCheckingAuth(false);
      }
    );

    // Clean up Firebase listener
    return unsubscribe;
  }, []);

  // Firebase is still checking whether
  // the user is already signed in.
  if (checkingAuth) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" />

        <Text style={styles.loadingText}>
          Checking authentication...
        </Text>
      </View>
    );
  }

  // No authenticated user
  if (!user) {
    return <AuthScreen />;
  }

  // Authenticated user
  return <ProfileScreen />;
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  loadingText: {
    marginTop: 15,
    fontSize: 16,
  },
});