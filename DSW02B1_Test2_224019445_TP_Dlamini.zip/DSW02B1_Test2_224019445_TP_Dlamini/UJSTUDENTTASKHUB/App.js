import React, { useEffect, useState } from "react";

import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
} from "react-native";

import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  onSnapshot,
  serverTimestamp,
} from "firebase/firestore";

import { db } from "./firebase";

import TaskForm from "./components/TaskForm";
import TaskList from "./components/TaskList";

export default function App() {

  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // READ TASKS IN REAL TIME
  useEffect(() => {

    setLoading(true);
    setError("");

    const tasksCollection = collection(db, "tasks");

    const unsubscribe = onSnapshot(
      tasksCollection,

      (snapshot) => {

        const taskData = snapshot.docs.map((document) => ({
          id: document.id,
          ...document.data(),
        }));

        setTasks(taskData);
        setLoading(false);
      },

      (error) => {

        console.error(error);

        setError(
          "Unable to load tasks from Firestore."
        );

        setLoading(false);
      }
    );

    return () => {
      unsubscribe();
    };

  }, []);

  const addTask = async (task) => {

    try {

      await addDoc(
        collection(db, "tasks"),
        {
          title: task.title,
          moduleCode: task.moduleCode,
          priority: task.priority,
          completed: false,
          createdAt: serverTimestamp(),
        }
      );

    } catch (error) {

      console.error(error);

      throw error;
    }
  };

  const toggleTask = async (task) => {

    try {

      const taskRef = doc(
        db,
        "tasks",
        task.id
      );

      await updateDoc(
        taskRef,
        {
          completed: !task.completed,
        }
      );

    } catch (error) {

      console.error(error);

      setError(
        "Unable to update the task."
      );
    }
  };
  
  const deleteTask = async (taskId) => {

    try {

      const taskRef = doc(
        db,
        "tasks",
        taskId
      );

      await deleteDoc(taskRef);

    } catch (error) {

      console.error(error);

      setError(
        "Unable to delete the task."
      );
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>

      <View style={styles.container}>

        <Text style={styles.title}>
          UJ Student Task Hub
        </Text>

        <Text style={styles.subtitle}>
          Manage your academic tasks
        </Text>

        <TaskForm
          onAddTask={addTask}
        />

        <Text style={styles.tasksHeading}>
          My Tasks
        </Text>

        <View style={styles.listContainer}>

          <TaskList
            tasks={tasks}
            loading={loading}
            error={error}
            onToggle={toggleTask}
            onDelete={deleteTask}
          />

        </View>

      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({

  safeArea: {
    flex: 1,
    backgroundColor: "#eeeeee",
  },

  container: {
    flex: 1,
    padding: 15,
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 15,
  },

  subtitle: {
    textAlign: "center",
    color: "#666666",
    marginBottom: 20,
  },

  tasksHeading: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 10,
  },

  listContainer: {
    flex: 1,
  },

});