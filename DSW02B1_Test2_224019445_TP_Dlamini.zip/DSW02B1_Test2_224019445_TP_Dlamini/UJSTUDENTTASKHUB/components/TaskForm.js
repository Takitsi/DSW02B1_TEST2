import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";

const TaskForm = ({ onAddTask }) => {
  const [title, setTitle] = useState("");
  const [moduleCode, setModuleCode] = useState("");
  const [priority, setPriority] = useState("");

  const handleSubmit = async () => {
    if (!title.trim() || !moduleCode.trim() || !priority) {
      Alert.alert(
        "Validation Error",
        "Please enter the task title, module code and priority."
      );
      return;
    }

    try {
      await onAddTask({
        title: title.trim(),
        moduleCode: moduleCode.trim(),
        priority: priority,
      });

      setTitle("");
      setModuleCode("");
      setPriority("");
    } catch (error) {
      Alert.alert("Error", "The task could not be created.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Create New Task</Text>

      <Text style={styles.label}>Task Title</Text>

      <TextInput
        style={styles.input}
        placeholder="Enter task title"
        value={title}
        onChangeText={setTitle}
      />

      <Text style={styles.label}>Module Code</Text>

      <TextInput
        style={styles.input}
        placeholder="Example: DSW02B1"
        value={moduleCode}
        onChangeText={setModuleCode}
        autoCapitalize="characters"
      />

      <Text style={styles.label}>Priority</Text>

      <View style={styles.priorityContainer}>
        {["Low", "Medium", "High"].map((item) => (
          <TouchableOpacity
            key={item}
            style={[
              styles.priorityButton,
              priority === item && styles.selectedPriority,
            ]}
            onPress={() => setPriority(item)}
          >
            <Text
              style={[
                styles.priorityText,
                priority === item && styles.selectedPriorityText,
              ]}
            >
              {item}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        style={styles.addButton}
        onPress={handleSubmit}
      >
        <Text style={styles.addButtonText}>
          ADD TASK
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#ffffff",
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
  },

  heading: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 15,
  },

  label: {
    fontSize: 14,
    fontWeight: "bold",
    marginBottom: 5,
  },

  input: {
    borderWidth: 1,
    borderColor: "#cccccc",
    borderRadius: 8,
    padding: 12,
    marginBottom: 15,
  },

  priorityContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 15,
  },

  priorityButton: {
    borderWidth: 1,
    borderColor: "#999999",
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },

  selectedPriority: {
    backgroundColor: "#333333",
  },

  priorityText: {
    color: "#333333",
  },

  selectedPriorityText: {
    color: "#ffffff",
  },

  addButton: {
    backgroundColor: "#222222",
    padding: 14,
    borderRadius: 8,
    alignItems: "center",
  },

  addButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
});

export default TaskForm;