import React from "react";
import {
  View,
  Text,
  FlatList,
  ActivityIndicator,
  StyleSheet,
} from "react-native";

import TaskCard from "./TaskCard";

const TaskList = ({
  tasks,
  loading,
  error,
  onToggle,
  onDelete,
}) => {

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />

        <Text style={styles.message}>
          Loading tasks...
        </Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.error}>
          {error}
        </Text>
      </View>
    );
  }

  if (tasks.length === 0) {
    return (
      <View style={styles.center}>
        <Text style={styles.message}>
          No tasks yet.
        </Text>

        <Text>
          Create your first academic task above.
        </Text>
      </View>
    );
  }

  return (
    <FlatList
      data={tasks}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <TaskCard
          task={item}
          onToggle={onToggle}
          onDelete={onDelete}
        />
      )}
    />
  );
};

const styles = StyleSheet.create({
  center: {
    alignItems: "center",
    padding: 20,
  },

  message: {
    marginTop: 10,
    fontSize: 16,
  },

  error: {
    color: "red",
    fontSize: 16,
    textAlign: "center",
  },
});

export default TaskList;