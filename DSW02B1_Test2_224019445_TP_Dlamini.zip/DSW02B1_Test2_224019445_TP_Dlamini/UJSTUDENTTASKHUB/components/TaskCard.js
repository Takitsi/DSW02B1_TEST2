import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from "react-native";

const TaskCard = ({ task, onToggle, onDelete }) => {
  return (
    <View style={styles.card}>

      <Text
        style={[
          styles.title,
          task.completed && styles.completedTitle,
        ]}
      >
        {task.title}
      </Text>

      <Text style={styles.info}>
        Module: {task.moduleCode}
      </Text>

      <Text style={styles.info}>
        Priority: {task.priority}
      </Text>

      <Text style={styles.status}>
        Status:{" "}
        {task.completed ? "Completed" : "Incomplete"}
      </Text>

      <View style={styles.buttons}>

        <TouchableOpacity
          style={styles.completeButton}
          onPress={() => onToggle(task)}
        >
          <Text style={styles.buttonText}>
            {task.completed
              ? "Mark Incomplete"
              : "Mark Completed"}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => onDelete(task.id)}
        >
          <Text style={styles.buttonText}>
            Delete
          </Text>
        </TouchableOpacity>

      </View>

    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#ffffff",
    padding: 15,
    borderRadius: 10,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#dddddd",
  },

  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 8,
  },

  completedTitle: {
    textDecorationLine: "line-through",
  },

  info: {
    fontSize: 14,
    marginBottom: 4,
  },

  status: {
    marginTop: 5,
    fontWeight: "bold",
  },

  buttons: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 12,
  },

  completeButton: {
    backgroundColor: "#444444",
    padding: 10,
    borderRadius: 6,
  },

  deleteButton: {
    backgroundColor: "#aa0000",
    padding: 10,
    borderRadius: 6,
  },

  buttonText: {
    color: "#ffffff",
    fontWeight: "bold",
  },
});

export default TaskCard;