import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Pressable,
  Animated,
  StyleSheet,
} from 'react-native';

// Example alert data
const alerts = [
  {
    id: '1',
    title: 'Campus Closure',
    message: 'The campus will close at 18:00 today.',
  },
  {
    id: '2',
    title: 'Library Alert',
    message: 'The library will close early today.',
  },
  {
    id: '3',
    title: 'Security Alert',
    message: 'Please remain aware of your surroundings.',
  },
  {
    id: '4',
    title: 'Transport Alert',
    message: 'UJ shuttle services may experience delays.',
  },
];

function App() {
  const [saved, setSaved] = useState([]);

  // 4.2 IMMUTABLE STATE HANDLING
  function toggleSaved(id) {
    setSaved((currentSaved) => {
      if (currentSaved.includes(id)) {
        // Remove the ID without changing the old array
        return currentSaved.filter((savedId) => savedId !== id);
      }

      // Add the ID without changing the old array
      return [...currentSaved, id];
    });
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>
        UJ Campus Alert Centre
      </Text>

      {/* 4.5 SAVED ALERT COUNT */}
      <Text style={styles.count}>
        Saved alerts: {saved.length}
      </Text>

      <FlatList
        data={alerts}

        // 4.3 STABLE LIST IDENTITY
        keyExtractor={(item) => item.id}

        renderItem={({ item }) => (
          <AlertCard
            item={item}
            isSaved={saved.includes(item.id)}
            toggleSaved={toggleSaved}
          />
        )}
      />
    </View>
  );
}

// Individual alert card
function AlertCard({ item, isSaved, toggleSaved }) {
  // 4.4 Animated.Value is created ONCE
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(-10)).current;

  // Animation runs when the card mounts.
  // It does NOT depend on isSaved.
  useEffect(() => {
    Animated.parallel([
      Animated.timing(opacity, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),

      // 4.5 Small upward entrance movement
      Animated.timing(translateY, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <Animated.View
      style={[
        styles.card,
        isSaved && styles.savedCard,

        {
          opacity: opacity,
          transform: [
            {
              translateY: translateY,
            },
          ],
        },
      ]}
    >
      <Text style={styles.title}>
        {item.title}
      </Text>

      <Text style={styles.message}>
        {item.message}
      </Text>

      <Pressable
        // 4.1 EVENT HANDLING
        // The function is called ONLY when pressed
        onPress={() => toggleSaved(item.id)}
        style={[
          styles.button,
          isSaved && styles.savedButton,
        ]}
      >
        <Text style={styles.buttonText}>
          {isSaved ? 'Saved ✓' : 'Save Alert'}
        </Text>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },

  heading: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 10,
  },

  count: {
    fontSize: 18,
    marginBottom: 15,
  },

  card: {
    backgroundColor: 'white',
    padding: 16,
    marginBottom: 12,
    borderRadius: 10,
  },

  savedCard: {
    borderWidth: 2,
    borderColor: 'green',
  },

  title: {
    fontSize: 19,
    fontWeight: 'bold',
    marginBottom: 6,
  },

  message: {
    fontSize: 15,
    marginBottom: 12,
  },

  button: {
    backgroundColor: '#333',
    padding: 10,
    borderRadius: 6,
    alignItems: 'center',
  },

  savedButton: {
    backgroundColor: 'green',
  },

  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default App;